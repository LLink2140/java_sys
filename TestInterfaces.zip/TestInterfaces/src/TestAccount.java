public class TestAccount
{
    public static void main(String[] args)
    {
        SavingsAccount account1 =new SavingsAccount();

        SavingsAccount account2 =new SavingsAccount("Alice",1000);

        System.out.println(account1.getDetails());

        System.out.println(account2.getDetails());

        // Display account details
        System.out.println("===== Account Details =====");
        System.out.println(account1.getDetails());

        // Display current balance
        System.out.println("\nCurrent Balance: £" + account1.getBalance());

        // Withdraw the default amount (£20)
        System.out.println("\n===== Withdraw Default Amount =====");
        account1.withdraw();

        // Withdraw a specified amount (£200)
        System.out.println("\n===== Withdraw £200 =====");
        account1.withdraw(200);

        // Add interest
        System.out.println("\n===== Add Interest =====");
        account1.addInterest();
        System.out.println("Balance after interest: £" + account1.getBalance());

        // Display updated details
        System.out.println("\n===== Updated Account Details =====");
        System.out.println(account1.getDetails());

        // Demonstrate static variable and static methods
        System.out.println("\n===== Static Interest Rate =====");
        System.out.println("Current Interest Rate: "
                + Account.getInterestRate() + "%");

        Account.setInterestRate(2.5);

        System.out.println("Updated Interest Rate: "
                + Account.getInterestRate() + "%");

        // Demonstrate polymorphism
        System.out.println("\n===== Polymorphism Example =====");
        Account account3 = new SavingsAccount("Bob", 5000);

        System.out.println(account3.getDetails());

        account3.addInterest();

        System.out.println("After adding interest:");
        System.out.println(account3.getDetails());
    }
}