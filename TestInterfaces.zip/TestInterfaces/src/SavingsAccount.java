public class SavingsAccount extends Account
{
    // Default constructor
    public SavingsAccount()
    {
        super();        // Calls Account()
    }

    // Parameterized constructor
    public SavingsAccount(String s, double d)
    {
        super(s, d);
    }

    @Override
    public void addInterest()
    {
        setBalance(getBalance() * 1.4);
    }
}